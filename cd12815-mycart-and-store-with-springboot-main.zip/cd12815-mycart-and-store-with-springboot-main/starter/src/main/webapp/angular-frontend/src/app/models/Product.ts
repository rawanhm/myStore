//TODO: Add the contents of the product class
export class Product {
id: number;
name: string;
amount: number;
price: number;
description: string;
image: string;
constructor() {
  this.id = 0;
  this.amount = 0;
  this.name = '';
  this.price = 0;
  this.description = '';
  this.image = '';
}}